var annotated_dup =
[
    [ "PeopleTracker", null, [
      [ "src", null, [
        [ "camera_position", null, [
          [ "CameraPosition", "a00142.html", "a00142" ]
        ] ],
        [ "centroidtracker", null, [
          [ "CentroidTracker", "a00146.html", null ]
        ] ],
        [ "datalogger", null, [
          [ "DataLogger", "a00150.html", "a00150" ]
        ] ],
        [ "evaluate", "a00111.html", [
          [ "tracker_evaluation", "a00154.html", "a00154" ]
        ] ],
        [ "filters", null, [
          [ "KalmanPred", "a00158.html", null ]
        ] ],
        [ "fps", null, [
          [ "FPS", "a00162.html", null ]
        ] ],
        [ "multiple_inputs", null, [
          [ "InputDialog", "a00166.html", null ]
        ] ],
        [ "multitracker", null, [
          [ "MultiTracker", "a00170.html", "a00170" ]
        ] ],
        [ "new_centroidtracker", null, [
          [ "NewCentroidTracker", "a00174.html", null ]
        ] ],
        [ "prank", null, [
          [ "MainWindow", "a00178.html", null ]
        ] ],
        [ "qt_dialog", null, [
          [ "App", "a00182.html", null ],
          [ "Image_Enhancement", "a00194.html", null ],
          [ "MaskRCNN_IOU_Options", "a00186.html", null ],
          [ "Predictor_Options", "a00190.html", null ]
        ] ],
        [ "Regions", null, [
          [ "Regions", "a00198.html", "a00198" ]
        ] ],
        [ "regression", null, [
          [ "rolling_regression", "a00202.html", "a00202" ]
        ] ],
        [ "room_estimation", null, [
          [ "room_estimation", "a00206.html", "a00206" ]
        ] ],
        [ "test_Multitracker", null, [
          [ "TestMultitracker", "a00210.html", null ]
        ] ],
        [ "test_Regions", null, [
          [ "TestRegions", "a00214.html", "a00214" ]
        ] ],
        [ "tracker_to_DLC", null, [
          [ "Converter", "a00218.html", null ]
        ] ],
        [ "TrackerTab", null, [
          [ "person_tab", "a00222.html", null ]
        ] ],
        [ "utils", "a00136.html", [
          [ "Dataset", "a00226.html", "a00226" ]
        ] ],
        [ "Video", null, [
          [ "FileVideoStream", "a00234.html", null ],
          [ "STFileVideoStream", "a00230.html", null ]
        ] ]
      ] ]
    ] ]
];