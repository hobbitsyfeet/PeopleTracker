var class_people_tracker_1_1src_1_1_regions_1_1_regions =
[
    [ "add_region", "class_people_tracker_1_1src_1_1_regions_1_1_regions.html#a89700c3be1f743a710b70fbc86d8dfe7", null ],
    [ "display_region", "class_people_tracker_1_1src_1_1_regions_1_1_regions.html#a4d1c2522bead251ed698af05ffb015d6", null ],
    [ "set_moving_region", "class_people_tracker_1_1src_1_1_regions_1_1_regions.html#ac69072c9e8f9bb71ae2107cfeab27ca3", null ],
    [ "test_region", "class_people_tracker_1_1src_1_1_regions_1_1_regions.html#a1e456cb1d544c85ca419094f660ed2dd", null ]
];