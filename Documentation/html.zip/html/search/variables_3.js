var searchData=
[
  ['data_5fdict_0',['data_dict',['../a00170.html#ac65effccfc0953d28e2002eb1514588d',1,'PeopleTracker::src::multitracker::MultiTracker']]],
  ['description_1',['description',['../a00170.html#a2661f439a4a94ffdcd5e47ae1da0bb1d',1,'PeopleTracker::src::multitracker::MultiTracker']]],
  ['distance_5fdata_2',['distance_data',['../a00170.html#ac419529d8eb4ccb715f990951ff0c6a6',1,'PeopleTracker::src::multitracker::MultiTracker']]]
];
