var searchData=
[
  ['regions_0',['Regions',['../a00198.html',1,'PeopleTracker::src::Regions']]],
  ['rolling_5fregression_1',['rolling_regression',['../a00202.html',1,'PeopleTracker::src::regression']]],
  ['room_5festimation_2',['room_estimation',['../a00206.html',1,'PeopleTracker::src::room_estimation']]]
];
