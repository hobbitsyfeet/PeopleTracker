var searchData=
[
  ['test_5fregion_0',['test_region',['../a00198.html#a1e456cb1d544c85ca419094f660ed2dd',1,'PeopleTracker::src::Regions::Regions']]],
  ['test_5ftest_5fregion_1',['test_test_region',['../a00214.html#a71f24ab7ecef358a30fdc8a74ef4fe58',1,'PeopleTracker::src::test_Regions::TestRegions']]],
  ['trim_5fzeros_2',['trim_zeros',['../a00136.html#a41cc5ed08039f095ef85d066b5ac5736',1,'PeopleTracker::src::utils']]]
];
