var searchData=
[
  ['person_5ftab_0',['person_tab',['../a00222.html',1,'PeopleTracker::src::TrackerTab']]],
  ['predictor_5foptions_1',['Predictor_Options',['../a00190.html',1,'PeopleTracker::src::qt_dialog']]]
];
