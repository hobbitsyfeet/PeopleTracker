var searchData=
[
  ['documentation_20page_0',['A documentation page',['../_bibliography.html',1,'']]]
];
