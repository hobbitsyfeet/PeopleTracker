var searchData=
[
  ['app_0',['App',['../a00182.html',1,'PeopleTracker::src::qt_dialog']]]
];
