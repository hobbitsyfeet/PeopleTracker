var searchData=
[
  ['batch_5fslice_0',['batch_slice',['../a00136.html#afa0874686dd08355e2d30e5ab1059e3e',1,'PeopleTracker::src::utils']]],
  ['box_5frefinement_1',['box_refinement',['../a00136.html#a91902236d996fed61ce52c46259ac538',1,'PeopleTracker::src::utils']]],
  ['box_5frefinement_5fgraph_2',['box_refinement_graph',['../a00136.html#a02d5a032da1926059b55a8c91cbc2610',1,'PeopleTracker::src::utils']]]
];
