var searchData=
[
  ['page_0',['A documentation page',['../_bibliography.html',1,'']]]
];
