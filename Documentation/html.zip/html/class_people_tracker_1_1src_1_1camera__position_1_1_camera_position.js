var class_people_tracker_1_1src_1_1camera__position_1_1_camera_position =
[
    [ "collect_frames", "class_people_tracker_1_1src_1_1camera__position_1_1_camera_position.html#adcab0c33567748a21cfc4a90e663c1d6", null ],
    [ "find_features", "class_people_tracker_1_1src_1_1camera__position_1_1_camera_position.html#acd6111030323a0e90c7070360c9a8363", null ]
];