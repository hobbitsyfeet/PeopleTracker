var hierarchy =
[
    [ "CentroidTracker", "a00146.html", null ],
    [ "Converter", "a00218.html", null ],
    [ "DataLogger", "a00150.html", null ],
    [ "FileVideoStream", "a00234.html", null ],
    [ "FPS", "a00162.html", null ],
    [ "KalmanPred", "a00158.html", null ],
    [ "MultiTracker", "a00170.html", null ],
    [ "NewCentroidTracker", "a00174.html", null ],
    [ "object", null, [
      [ "Dataset", "a00226.html", null ]
    ] ],
    [ "person_tab", "a00222.html", null ],
    [ "QWidget", null, [
      [ "App", "a00182.html", null ],
      [ "Image_Enhancement", "a00194.html", null ],
      [ "MaskRCNN_IOU_Options", "a00186.html", null ],
      [ "Predictor_Options", "a00190.html", null ]
    ] ],
    [ "rolling_regression", "a00202.html", null ],
    [ "room_estimation", "a00206.html", null ],
    [ "STFileVideoStream", "a00230.html", null ],
    [ "TestCase", null, [
      [ "TestMultitracker", "a00210.html", null ],
      [ "TestRegions", "a00214.html", null ]
    ] ],
    [ "tracker_evaluation", "a00154.html", null ],
    [ "QDialog", null, [
      [ "InputDialog", "a00166.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "a00178.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "Regions", "a00198.html", null ],
      [ "CameraPosition", "a00142.html", null ]
    ] ]
];