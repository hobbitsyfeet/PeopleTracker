var a00202 =
[
    [ "get_direction", "a00202.html#a62184a9a176b1dfbacfa5c2349073dfc", null ]
];