var class_people_tracker_1_1src_1_1regression_1_1rolling__regression =
[
    [ "get_direction", "class_people_tracker_1_1src_1_1regression_1_1rolling__regression.html#a62184a9a176b1dfbacfa5c2349073dfc", null ]
];