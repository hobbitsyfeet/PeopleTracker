var a00142 =
[
    [ "collect_frames", "a00142.html#adcab0c33567748a21cfc4a90e663c1d6", null ],
    [ "find_features", "a00142.html#acd6111030323a0e90c7070360c9a8363", null ]
];